import{e as o,a as v}from"./index-CTOhI4wR.js";import{W as g,e as M}from"./deep-link-C5I0oCRJ.js";import{a as l,M as u}from"./types-DwmwTY6P.js";function _(t,e){let n;return(...i)=>{n!==void 0&&clearTimeout(n),n=setTimeout(()=>t(...i),e)}}const H=["https://weread.qq.com/web/search/global"];function R(t){if(!t||typeof t!="object")return!1;const e=t.bookInfo;if(!e||typeof e!="object")return!1;const{bookId:n,title:i}=e;return(typeof n=="string"||typeof n=="number")&&typeof i=="string"}function x(t){const e=t.bookInfo;if(e.deepLink){const n=M(e.deepLink);return n?`https://weread.qq.com/web/reader/${n}`:e.deepLink}return`https://weread.qq.com/web/reader/${e.bookId}`}function j(t){const e=document.getElementById("searchResults");let n=!1;const i=_(async s=>{if(!e||n)return;n=!0;const r=setTimeout(()=>{n=!1},15e3);e.hidden=!1,e.innerHTML='<div class="search-loading">搜索中...</div>';try{let d=[];for(const c of H)try{const a=await fetch(`${c}?keyword=${encodeURIComponent(s)}`,{method:"GET",credentials:"include",headers:{Accept:"application/json"}});if(a.ok){const k=await a.json();console.log("[popup] 搜索 API 返回:",k);const $=k.books??k.result??[];if(d=Array.isArray($)?$.filter(R):[],console.log(`[popup] 搜索结果数量: ${d.length}`),d.length>0)break}else console.warn(`[popup] 搜索 API 状态码: ${a.status}`)}catch(a){console.warn(`[popup] 搜索端点 ${c} 失败:`,a)}if(d.length===0){e.innerHTML=`
        <div class="search-empty">API 调用失败，点击跳转到微信读书搜索</div>
        <a class="search-result-item" href="${g.SEARCH(s)}" target="_blank" rel="noopener">
          <div class="search-result-meta">
            <p class="search-result-title">在微信读书中搜索「${o(s)}」</p>
          </div>
        </a>`;return}const f=d.slice(0,10).map(c=>`
      <div class="search-result-item" data-book-id="${o(String(c.bookInfo.bookId??""))}" data-book-title="${o(c.bookInfo.title)}" data-book-author="${o(c.bookInfo.author??"")}">
        <a class="search-result-link" href="${o(x(c))}" target="_blank" rel="noopener">
          <img class="search-result-cover" src="${o(c.bookInfo.cover??"")}" alt="" onerror="this.style.visibility='hidden'" />
          <div class="search-result-meta">
            <p class="search-result-title">${o(c.bookInfo.title)}</p>
            <p class="search-result-author">${o(c.bookInfo.author??"")}</p>
            ${c.bookInfo.intro?`<p class="search-result-intro">${o(c.bookInfo.intro.slice(0,50))}</p>`:""}
          </div>
        </a>
      </div>`).join("");e.innerHTML=`<div class="search-results-list">${f}</div>`}finally{clearTimeout(r),n=!1}},300);t.addEventListener("keydown",s=>{if(s.key!=="Enter")return;s.preventDefault();const r=t.value.trim();r&&i(r)}),document.addEventListener("click",s=>{e&&(s.target===t||e.contains(s.target)||(e.hidden=!0))})}async function L(t,e){const[n,i]=await Promise.all([l({type:u.GET_ACTIVE}),l({type:u.LIST_ACCOUNTS})]);if(!n){t.innerHTML=`
      <div class="empty-state">
        <div class="empty-icon">👤</div>
        <div data-i18n="noAccount">暂无保存的账户</div>
      </div>`,v(t);return}const s=i.filter(d=>d.id!==n.id),r=s.length?`<div class="account-others">
        ${s.map(d=>`
          <button class="account-switch" data-id="${o(d.id)}" title="${o(d.name)}">
            ${o(d.name)}
          </button>`).join("")}
      </div>`:"";t.innerHTML=`
    <div class="account-card">
      <div class="account-avatar">👤</div>
      <div class="account-meta">
        <p class="account-name">${o(n.name)}</p>
        <p class="account-sub">${n.userId?"ID: "+o(n.userId):'<span data-i18n="savedAccount">已保存</span>'}</p>
      </div>
    </div>
    ${r}`,v(t),t.querySelectorAll(".account-switch[data-id]").forEach(d=>{d.addEventListener("click",async()=>{const f=d.dataset.id;if(f)try{await l({type:u.SET_ACTIVE,payload:{id:f}}),I("已切换账户"),e()}catch(c){I(`切换失败: ${c.message}`)}})})}function I(t){const e=document.getElementById("toast");e&&(e.textContent=t,e.hidden=!1,setTimeout(()=>{e.hidden=!0},2e3))}function q(t){if(!t)return"";const e=Date.now()-t,n=24*60*60*1e3;return e<n?"今天读过":e<2*n?"昨天读过":e<7*n?`${Math.floor(e/n)}天前读过`:""}function O(t){if(!t||t<=0)return"";const e=Math.floor(t/3600),n=Math.floor(t%3600/60);return e>0?`${e}小时${n>0?n+"分":""}`:n>0?`${n}分钟`:"<1分钟"}function b(t,e){const n=t.querySelector(".shelf-refresh-btn");n&&n.addEventListener("click",()=>{n.disabled=!0,n.textContent="⏳ 刷新中...",n.classList.add("loading"),setTimeout(()=>{try{e()}finally{n.disabled=!1,n.textContent="🔄 刷新",n.classList.remove("loading")}},50)})}async function T(t,e){const n=await l({type:u.GET_SHELF_PREVIEW}).catch(()=>[]),i=`
    <div class="shelf-header">
      <p class="shelf-title" data-i18n="shelfTitle">最近在读</p>
      ${e?'<button class="shelf-refresh-btn" title="刷新阅读列表">🔄 刷新</button>':""}
    </div>`;if(n.length===0){t.innerHTML=`
      ${i}
      <div class="shelf-empty">
        <a class="shelf-link" href="${g.SHELF}" target="_blank" rel="noopener" data-i18n="myShelf">我的书架</a>
        <a class="shelf-link" href="${g.NOTE}" target="_blank" rel="noopener" data-i18n="myNotes">我的笔记</a>
        <a class="shelf-link" href="${g.HOME}" target="_blank" rel="noopener" data-i18n="explore">发现</a>
      </div>`,e&&b(t,e),v(t);return}const s=n.map(r=>{const d=Math.max(0,Math.min(100,Math.round(r.progress*100))),f=q(r.lastReadTime),c=O(r.readingTime??0);return`
    <div class="book-item" data-book-id="${o(r.bookIdNum||r.bookId)}" data-book-title="${o(r.title)}">
      <a class="book-item-link" href="${o(r.url)}" target="_blank" rel="noopener">
        <img class="book-cover" src="${o(r.cover)}" alt="" onerror="this.style.visibility='hidden'" />
        <div class="book-meta">
          <p class="book-title">${o(r.title)}</p>
          <p class="book-author">${o(r.author)}</p>
          <div class="book-progress-row">
            <div class="book-progress">
              <div class="book-progress-bar" style="width:${d}%"></div>
            </div>
            <span class="book-progress-text">${d}%</span>
          </div>
          <p class="book-extra">
            ${c?`<span class="book-read-time">⏱ ${c}</span>`:""}
            ${f?`<span class="book-last-read">${f}</span>`:""}
          </p>
        </div>
      </a>
    </div>`}).join("");t.innerHTML=`${i}<div class="book-list">${s}</div>`,e&&b(t,e),v(t)}const w="https://weread.qq.com/";let E=null;async function N(){const t=document.getElementById("jsStatus");t&&(t.textContent="JS已执行"),V(),v(),m("account",()=>L(B(),h)),m("shelf",()=>T(A(),h)),m("continue",S),m("autoLogin",U)}function D(){const t=document.querySelectorAll(".tab-btn"),e=document.querySelectorAll(".tab-content");t.forEach(n=>{n.addEventListener("click",()=>{const i=n.dataset.tab;t.forEach(s=>s.classList.toggle("active",s===n)),e.forEach(s=>s.classList.toggle("active",s.id===`tab-${i}`)),i==="settings"&&(m("shelfBoard",C),m("accountList",y))})})}async function S(){const t=await l({type:u.GET_RECENT_BOOK}).catch(()=>null),e=document.getElementById("continueReading");if(!e)return;if(!t){e.hidden=!0;return}E=t.url;const n=document.getElementById("continueCover"),i=document.getElementById("continueTitle"),s=document.getElementById("continueAuthor"),r=document.getElementById("continueMeta");if(n&&(n.src=t.cover),i&&(i.textContent=t.title),s&&(s.textContent=t.author),r){const d=Math.round(t.progress*100),f=t.readingTime?Math.floor(t.readingTime/3600):0,c=t.readingTime?Math.floor(t.readingTime%3600/60):0,a=f>0?`${f}小时${c>0?c+"分":""}`:c>0?`${c}分钟`:"";r.textContent=a?`进度 ${d}% · 已读 ${a}`:`进度 ${d}%`}e.hidden=!1}function h(){m("account",()=>L(B(),h)),m("shelf",()=>T(A(),h)),m("continue",S)}async function U(){const t=await l({type:u.GET_AUTO_LOGIN}),e=document.getElementById("autoLoginSwitch");e&&(e.checked=t)}function B(){return document.getElementById("accountSection")}function A(){return document.getElementById("shelfSection")}async function C(){const t=document.getElementById("shelfBoard");if(t){t.innerHTML='<div class="empty-state">加载中...</div>';try{const e=await l({type:u.GET_ALL_SHELF});P(e)}catch{t.innerHTML='<div class="empty-state">⚠️ 书架加载失败，请确认已登录微信读书</div>'}}}function P(t){const e=t.length,n=t.filter(a=>a.progress<1).length,i=t.filter(a=>a.progress>=1).length;document.getElementById("statTotal").textContent=String(e),document.getElementById("statReading").textContent=String(n),document.getElementById("statFinished").textContent=String(i);const s=document.getElementById("shelfBoard");if(e===0){s.innerHTML='<div class="empty-state">书架为空</div>';return}const r=t.filter(a=>a.progress>0&&a.progress<1),d=t.filter(a=>a.progress===0),f=t.filter(a=>a.progress>=1),c=[...r,...d,...f].slice(0,30);s.innerHTML=`
    <div class="shelf-grid-mini">
      ${c.map(a=>`
        <a class="book-card-mini" href="${o(G(a))}" target="_blank">
          <img class="book-cover-mini" src="${o(a.cover||"")}" alt="" onerror="this.style.visibility='hidden'" />
          <div class="book-info-mini">
            <div class="book-title-mini" title="${o(a.title)}">${o(a.title)}</div>
            <div class="book-progress-mini">
              <div class="book-progress-fill-mini" style="width:${Math.round(a.progress*100)}%"></div>
            </div>
          </div>
        </a>`).join("")}
    </div>`}function G(t){return t.url||`https://weread.qq.com/web/reader/${t.bookId}`}async function y(){const t=await l({type:u.LIST_ACCOUNTS}),e=document.getElementById("accountList");if(t.length===0){e.innerHTML='<div class="empty-state">暂无账户，请在 weread 页面保存账户</div>';return}e.innerHTML=t.map(n=>`
      <div class="account-row-mini${n.isActive?" active":""}" data-id="${o(n.id)}">
        <div class="account-row-meta-mini">
          <div class="account-row-name">${o(n.name)}</div>
          <div class="account-row-sub">${n.isActive?"当前账户":"ID: "+o(n.id)}</div>
        </div>
        <div class="account-row-actions-mini">
          ${n.isActive?"":`<button class="btn-mini js-activate" data-id="${o(n.id)}">切换</button>`}
          <button class="btn-mini js-remove" data-id="${o(n.id)}">删除</button>
        </div>
      </div>`).join(""),e.querySelectorAll(".js-activate").forEach(n=>{n.addEventListener("click",async()=>{const i=n.dataset.id;i&&(await l({type:u.SET_ACTIVE,payload:{id:i}}),p("已切换账户"),await y(),h())})}),e.querySelectorAll(".js-remove").forEach(n=>{n.addEventListener("click",async()=>{const i=n.dataset.id;i&&confirm("确定删除此账户？")&&(await l({type:u.REMOVE_ACCOUNT,payload:{id:i}}),p("已删除账户"),await y(),h())})})}function V(){D(),document.getElementById("openBtn")?.addEventListener("click",W),document.getElementById("saveBtn")?.addEventListener("click",J),document.getElementById("continueBtn")?.addEventListener("click",F),document.getElementById("autoLoginSwitch")?.addEventListener("change",K),document.getElementById("refreshShelfBtn")?.addEventListener("click",()=>void C()),document.getElementById("clearAllBtn")?.addEventListener("click",z);const t=document.getElementById("searchInput");t&&j(t)}async function F(){E?(await chrome.tabs.create({url:E}),window.close()):(await chrome.tabs.create({url:w}),window.close())}async function W(){try{await chrome.tabs.create({url:w}),window.close()}catch(t){p(`打开失败: ${t.message}`)}}async function J(){try{await l({type:u.SAVE_CURRENT}),p("账户信息已保存"),h()}catch(t){p(`保存失败: ${t.message}`)}}async function K(t){const e=t.target.checked;await l({type:u.SET_AUTO_LOGIN,payload:{autoLogin:e}}),p(e?"已开启自动登录":"已关闭自动登录")}async function z(){confirm("确定要清除全部账户吗？此操作不可恢复。")&&(await l({type:u.CLEAR_ALL}),p("已清除全部账户"),await y(),h())}function m(t,e){let n;try{n=e()}catch(i){n=Promise.reject(i)}n.catch(i=>{console.warn(`[popup] ${t} 渲染失败:`,i)})}function p(t){const e=document.getElementById("toast");e&&(e.textContent=t,e.hidden=!1,setTimeout(()=>{e.hidden=!0},2e3))}document.addEventListener("DOMContentLoaded",N);
//# sourceMappingURL=index.html-DAtNJQCv.js.map
