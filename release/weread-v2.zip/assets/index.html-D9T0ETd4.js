import{a as y,e as o}from"./index-CTOhI4wR.js";import{a as s,M as c}from"./types-DwmwTY6P.js";async function p(){y(),await Promise.all([d(),$(),f()]),S()}async function f(){const t=document.getElementById("shelfBoard");t.innerHTML='<div class="empty-state">加载中...</div>';try{const e=await s({type:c.GET_ALL_SHELF});E(e)}catch{t.innerHTML='<div class="empty-state">⚠️ 书架加载失败，请确认已在浏览器登录微信读书</div>'}}function E(t){const e=t.length,a=t.filter(n=>n.progress<1).length,i=t.filter(n=>n.progress>=1).length;document.getElementById("statTotal").textContent=String(e),document.getElementById("statReading").textContent=String(a),document.getElementById("statFinished").textContent=String(i);const r=document.getElementById("shelfBoard");if(e===0){r.innerHTML='<div class="empty-state">书架为空，请先在微信读书添加书籍</div>';return}const v=t.filter(n=>n.progress>0&&n.progress<1),l=t.filter(n=>n.progress===0),u=t.filter(n=>n.progress>=1),g=[...v,...l,...u];r.innerHTML=`
    <div class="shelf-grid">
      ${g.map(n=>`
        <a class="book-card" href="${o(h(n))}" target="_blank">
          <img class="book-cover" src="${o(n.cover||"")}" alt="${o(n.title)}" onerror="this.style.visibility='hidden'" />
          <div class="book-info">
            <div class="book-title" title="${o(n.title)}">${o(n.title)}</div>
            <div class="book-author">${o(n.author||"未知作者")}</div>
            <div class="book-progress-bar">
              <div class="book-progress-fill" style="width:${Math.round(n.progress*100)}%"></div>
            </div>
            <div class="book-meta">
              <span>${Math.round(n.progress*100)}%</span>
              <span>${w(n.lastReadTime)}</span>
            </div>
          </div>
        </a>`).join("")}
    </div>`}function h(t){return t.url||`https://weread.qq.com/web/reader/${t.bookId}`}function w(t){if(!t)return"未读";const a=Date.now()-t,i=24*60*60*1e3;if(a<i)return"今天读过";if(a<2*i)return"昨天读过";if(a<7*i)return`${Math.floor(a/i)}天前读过`;const r=new Date(t);return`${r.getMonth()+1}/${r.getDate()}读过`}async function d(){const t=await s({type:c.LIST_ACCOUNTS}),e=document.getElementById("accountList");if(t.length===0){e.innerHTML='<div class="account-row" style="text-align:center;color:var(--color-text-muted)">暂无账户，请在 weread 页面打开扩展弹窗保存账户</div>';return}e.innerHTML=t.map(a=>`
      <div class="account-row${a.isActive?" active":""}" data-id="${o(a.id)}">
        <div class="account-row-meta">
          <div class="account-row-name" data-mode="view">${o(a.name)}</div>
          <div class="account-row-sub">ID: ${o(a.id)} · 创建于 ${T(a.createdAt)}</div>
        </div>
        <div class="account-row-actions">
          ${a.isActive?'<button class="btn-mini" disabled>当前</button>':`<button class="btn-mini js-activate" data-id="${o(a.id)}">设为当前</button>`}
          <button class="btn-mini js-rename" data-id="${o(a.id)}">重命名</button>
          <button class="btn-mini danger js-remove" data-id="${o(a.id)}">删除</button>
        </div>
      </div>`).join(""),L()}function L(){document.querySelectorAll(".js-activate").forEach(t=>{t.addEventListener("click",async()=>{const e=t.dataset.id;e&&(await s({type:c.SET_ACTIVE,payload:{id:e}}),await d())})}),document.querySelectorAll(".js-rename").forEach(t=>{t.addEventListener("click",()=>{const e=t.closest(".account-row");if(!e)return;const a=t.dataset.id,i=e.querySelector(".account-row-meta"),v=i.querySelector("[data-mode]").textContent??"";i.innerHTML=`
        <input type="text" class="rename-input" value="${o(v)}" />
        <div class="account-row-actions">
          <button class="btn-mini js-rename-confirm" data-id="${o(a??"")}">确定</button>
          <button class="btn-mini js-rename-cancel">取消</button>
        </div>`;const l=i.querySelector(".rename-input");l.focus(),l.select(),i.querySelector(".js-rename-confirm")?.addEventListener("click",async()=>{const u=l.value.trim();u&&(await s({type:c.RENAME_ACCOUNT,payload:{id:a,name:u}}),await d())}),i.querySelector(".js-rename-cancel")?.addEventListener("click",d)})}),document.querySelectorAll(".js-remove").forEach(t=>{t.addEventListener("click",async()=>{const e=t.dataset.id;e&&confirm("确定删除此账户？")&&(await s({type:c.REMOVE_ACCOUNT,payload:{id:e}}),await d())})})}async function $(){const t=await s({type:c.GET_AUTO_LOGIN}),e=document.getElementById("autoLoginSwitch");e&&(e.checked=t)}function S(){document.getElementById("autoLoginSwitch")?.addEventListener("change",async t=>{const e=t.target.checked;await s({type:c.SET_AUTO_LOGIN,payload:{autoLogin:e}})}),document.getElementById("clearAllBtn")?.addEventListener("click",async()=>{confirm("确定清除全部账户？此操作不可恢复。")&&(await s({type:c.CLEAR_ALL}),await d())}),document.getElementById("refreshShelfBtn")?.addEventListener("click",f)}function T(t){const e=new Date(t);return`${e.getFullYear()}-${m(e.getMonth()+1)}-${m(e.getDate())} ${m(e.getHours())}:${m(e.getMinutes())}`}function m(t){return String(t).padStart(2,"0")}document.addEventListener("DOMContentLoaded",p);
//# sourceMappingURL=index.html-D9T0ETd4.js.map
